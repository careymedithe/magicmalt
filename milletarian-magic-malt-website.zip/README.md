# Milletarian Magic Malt responsive website

Static responsive website built from the content and brand assets of the supplied Milletarian source site.

## Run locally
Open `index.html` directly, or run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.
